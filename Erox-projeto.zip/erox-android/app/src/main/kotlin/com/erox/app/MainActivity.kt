package com.erox.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/**
 * Tela única do Erox: bloqueio por digital + conversa por texto e voz.
 * Toda a interface é montada em código para o projeto não depender de nenhuma biblioteca externa.
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private class PrefsStore(private val prefs: SharedPreferences) : Store {
        override fun get(key: String): String? = prefs.getString("brain_$key", null)
        override fun put(key: String, value: String) {
            prefs.edit().putString("brain_$key", value).apply()
        }
        override fun remove(key: String) {
            prefs.edit().remove("brain_$key").apply()
        }
    }

    private val main = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var brain: Brain

    private lateinit var lockLayer: LinearLayout
    private lateinit var orb: FingerprintOrb
    private lateinit var lockSubtitle: TextView
    private lateinit var lockButton: TextView

    private lateinit var chatLayer: LinearLayout
    private lateinit var statusView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var micButton: ImageButton
    private lateinit var voiceButton: ImageButton

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speakReplies = true

    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    private var unlocked = false
    private var authBusy = false
    private var needsEnroll = false
    private var autoPromptAllowed = true
    private var authCancel: CancellationSignal? = null
    private var leftAt = 0L

    private var timerRunnable: Runnable? = null

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Esconde o conteúdo na lista de apps recentes e impede capturas de tela.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        prefs = getSharedPreferences("erox", Context.MODE_PRIVATE)
        brain = Brain(PrefsStore(prefs))
        speakReplies = prefs.getBoolean("speak", true)

        setContentView(buildUi())
        tts = TextToSpeech(this, this)
        showLock("Toque na digital para entrar.", error = false)
    }

    override fun onResume() {
        super.onResume()
        if (!unlocked && autoPromptAllowed) {
            autoPromptAllowed = false
            startAuth()
        }
    }

    override fun onStart() {
        super.onStart()
        if (unlocked && leftAt != 0L && SystemClock.elapsedRealtime() - leftAt > LOCK_AFTER_MS) {
            lock()
        }
    }

    override fun onStop() {
        super.onStop()
        leftAt = SystemClock.elapsedRealtime()
        autoPromptAllowed = true
        authCancel?.cancel()
        authCancel = null
        authBusy = false
        stopListening(cancel = true)
        tts?.stop()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ montagem da interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun roundRect(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun circle(color: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }

    private fun iconButton(iconRes: Int, description: String, background: Int, tint: Int, onClick: () -> Unit): ImageButton =
        ImageButton(this).apply {
            setImageResource(iconRes)
            imageTintList = ColorStateList.valueOf(tint)
            this.background = circle(background)
            scaleType = ImageView.ScaleType.CENTER
            contentDescription = description
            setOnClickListener { onClick() }
        }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Palette.BG)
        root.addView(buildLockLayer(), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(buildChatLayer(), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return root
    }

    private fun buildLockLayer(): View {
        orb = FingerprintOrb(this)
        orb.setOnClickListener { onLockButton() }

        val title = TextView(this).apply {
            text = "EROX"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.28f
            setTextColor(Palette.TEXT)
            gravity = Gravity.CENTER
        }

        lockSubtitle = TextView(this).apply {
            textSize = 15f
            setTextColor(Palette.MUTED)
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.15f)
        }

        lockButton = TextView(this).apply {
            text = "Entrar com digital"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.ON_ACCENT)
            gravity = Gravity.CENTER
            background = roundRect(Palette.ACCENT, dp(28))
            setPadding(dp(32), dp(14), dp(32), dp(14))
            minHeight = dp(52)
            isClickable = true
            isFocusable = true
            setOnClickListener { onLockButton() }
        }

        val note = TextView(this).apply {
            text = "Suas anotações e conversas ficam só neste celular."
            textSize = 12f
            setTextColor(Palette.MUTED)
            gravity = Gravity.CENTER
        }

        lockLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Palette.BG)
            setPadding(dp(24), dp(24), dp(24), dp(24))
            addView(orb, LinearLayout.LayoutParams(dp(210), dp(210)))
            addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(20) })
            addView(lockSubtitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
            addView(lockButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(28)
                gravity = Gravity.CENTER_HORIZONTAL
            })
            addView(note, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(36) })
        }
        return lockLayer
    }

    private fun buildChatLayer(): View {
        val title = TextView(this).apply {
            text = "Erox"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.TEXT)
        }
        statusView = TextView(this).apply {
            text = "assistente local"
            textSize = 12f
            setTextColor(Palette.MUTED)
        }
        val titleColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(statusView)
        }

        voiceButton = iconButton(
            if (speakReplies) R.drawable.ic_volume_on else R.drawable.ic_volume_off,
            if (speakReplies) "Desligar a voz do Erox" else "Ligar a voz do Erox",
            Palette.SURFACE, Palette.TEXT,
        ) { toggleSpeaking() }
        val lockNow = iconButton(R.drawable.ic_lock, "Bloquear o Erox", Palette.SURFACE, Palette.TEXT) { lock() }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addView(titleColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(voiceButton, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(lockNow, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        }

        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(16))
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(messages, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        input = EditText(this).apply {
            hint = "Escreva ou toque no microfone"
            setHintTextColor(Palette.MUTED)
            setTextColor(Palette.TEXT)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            maxLines = 1
            background = roundRect(Palette.SURFACE, dp(26))
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendTyped()
                    true
                } else {
                    false
                }
            }
        }
        micButton = iconButton(R.drawable.ic_mic, "Falar com o Erox", Palette.SURFACE_HI, Palette.TEXT) { toggleListening() }
        val send = iconButton(R.drawable.ic_send, "Enviar", Palette.ACCENT, Palette.ON_ACCENT) { sendTyped() }

        val inputBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(micButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
            addView(send, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        }

        chatLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.BG)
            visibility = View.GONE
            addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(inputBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return chatLayer
    }

    // ------------------------------------------------------------------ bloqueio e digital

    private fun showLock(message: String, error: Boolean) {
        lockSubtitle.text = message
        lockSubtitle.setTextColor(if (error) Palette.ERROR else Palette.MUTED)
        orb.tint = if (error) Palette.ERROR else Palette.ACCENT
        lockButton.text = if (needsEnroll) "Abrir configurações" else "Entrar com digital"
    }

    private fun onLockButton() {
        if (needsEnroll) openEnrollment() else startAuth()
    }

    private fun lock() {
        unlocked = false
        authCancel?.cancel()
        authCancel = null
        authBusy = false
        stopListening(cancel = true)
        tts?.stop()
        hideKeyboard()
        chatLayer.visibility = View.GONE
        lockLayer.visibility = View.VISIBLE
        showLock("Erox bloqueado. Toque na digital para entrar.", error = false)
    }

    private fun unlock() {
        unlocked = true
        authBusy = false
        authCancel = null
        needsEnroll = false
        leftAt = 0L
        lockLayer.visibility = View.GONE
        chatLayer.visibility = View.VISIBLE
        showLock("", error = false)
        if (messages.childCount == 0) {
            addBubble(brain.respond("oi").text + " Diga \"ajuda\" para ver o que eu sei fazer.", fromUser = false)
        }
    }

    private fun startAuth() {
        if (unlocked || authBusy) return

        val manager = getSystemService(BiometricManager::class.java)
        val status = when {
            manager == null -> BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
            Build.VERSION.SDK_INT >= 30 -> manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            else -> @Suppress("DEPRECATION") manager.canAuthenticate()
        }
        when (status) {
            BiometricManager.BIOMETRIC_SUCCESS -> Unit
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                needsEnroll = true
                showLock("Nenhuma digital cadastrada neste celular. Cadastre uma nas configurações e volte.", error = true)
                return
            }
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                showLock("Este celular não tem leitor de digital, então não consigo proteger o Erox.", error = true)
                return
            }
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                showLock("O leitor de digital está indisponível agora. Tente de novo em instantes.", error = true)
                return
            }
            else -> {
                showLock("Não consegui usar o leitor de digital (código $status).", error = true)
                return
            }
        }

        needsEnroll = false
        authBusy = true
        showLock("Encoste o dedo no leitor.", error = false)

        val executor = mainExecutor
        val builder = BiometricPrompt.Builder(this)
            .setTitle("Entrar no Erox")
            .setSubtitle("Use a sua digital")
            .setNegativeButton("Cancelar", executor) { _, _ ->
                authBusy = false
                showLock("Toque na digital para entrar.", error = false)
            }
        if (Build.VERSION.SDK_INT >= 30) {
            builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        }

        val cancel = CancellationSignal()
        authCancel = cancel
        builder.build().authenticate(cancel, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                unlock()
            }

            override fun onAuthenticationFailed() {
                showLock("Digital não reconhecida. Tente de novo.", error = true)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                authBusy = false
                when (errorCode) {
                    BiometricPrompt.BIOMETRIC_ERROR_CANCELED,
                    BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED ->
                        showLock("Toque na digital para entrar.", error = false)
                    BiometricPrompt.BIOMETRIC_ERROR_LOCKOUT ->
                        showLock("Muitas tentativas erradas. Espere alguns segundos e tente de novo.", error = true)
                    BiometricPrompt.BIOMETRIC_ERROR_LOCKOUT_PERMANENT ->
                        showLock("Leitor de digital bloqueado. Desbloqueie o celular com o PIN para voltar a usar.", error = true)
                    else ->
                        showLock(errString?.toString() ?: "Não deu para ler a digital.", error = true)
                }
            }
        })
    }

    private fun openEnrollment() {
        val intent = if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_BIOMETRIC_ENROLL).putExtra(
                Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                BiometricManager.Authenticators.BIOMETRIC_STRONG,
            )
        } else {
            Intent(Settings.ACTION_SECURITY_SETTINGS)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
            } catch (e2: Exception) {
                showLock("Abra as configurações do celular e cadastre uma digital.", error = true)
            }
        }
    }

    // ------------------------------------------------------------------ conversa

    private fun sendTyped() {
        val text = input.text.toString()
        if (text.isBlank()) return
        input.setText("")
        submit(text)
    }

    private fun submit(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        addBubble(clean, fromUser = true)
        val reply = try {
            brain.respond(clean)
        } catch (e: Exception) {
            Reply("Algo deu errado aqui dentro. Tente de novo.")
        }
        handle(reply)
    }

    private fun handle(reply: Reply) {
        when (val action = reply.action) {
            is Action.Timer -> {
                startTimer(action.seconds)
                addBubble(reply.text, fromUser = false)
                speak(reply.text)
            }
            Action.CancelTimer -> {
                cancelTimer()
                addBubble(reply.text, fromUser = false)
                speak(reply.text)
            }
            Action.Lock -> {
                addBubble(reply.text, fromUser = false)
                lock()
            }
            Action.ClearChat -> {
                messages.removeAllViews()
                addBubble(reply.text, fromUser = false)
            }
            Action.StopSpeaking -> {
                tts?.stop()
                addBubble(reply.text, fromUser = false)
            }
            Action.None -> {
                addBubble(reply.text, fromUser = false)
                speak(reply.text)
            }
        }
    }

    private fun addBubble(text: String, fromUser: Boolean) {
        val big = dp(18).toFloat()
        val small = dp(5).toFloat()
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 16f
            setLineSpacing(0f, 1.12f)
            setTextColor(if (fromUser) Palette.ON_ACCENT else Palette.TEXT)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(if (fromUser) Palette.ACCENT else Palette.SURFACE)
                // ordem: topo-esq, topo-dir, base-dir, base-esq (x e y de cada canto)
                cornerRadii = if (fromUser) {
                    floatArrayOf(big, big, big, big, small, small, big, big)
                } else {
                    floatArrayOf(big, big, big, big, big, big, small, small)
                }
            }
            maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
            setTextIsSelectable(true)
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            topMargin = dp(8)
        }
        messages.addView(bubble, params)
        scrollToEnd()
    }

    private fun addNotice(text: String) {
        val notice = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Palette.MUTED)
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.1f)
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        }
        messages.addView(notice, params)
        scrollToEnd()
    }

    private fun scrollToEnd() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(input.windowToken, 0)
    }

    // ------------------------------------------------------------------ voz: falar

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            return
        }
        val result = tts?.setLanguage(Locale.forLanguageTag("pt-BR"))
        ttsReady = result != null && result >= TextToSpeech.LANG_AVAILABLE
    }

    private fun speak(text: String, force: Boolean = false) {
        if (!speakReplies && !force) return
        val engine = tts ?: return
        if (!ttsReady) return
        var spoken = text.replace("•", " ").replace("→", " ")
        if (spoken.length > 280) spoken = spoken.substringBefore('\n') + ". O resto está na tela."
        engine.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "erox")
    }

    private fun toggleSpeaking() {
        speakReplies = !speakReplies
        prefs.edit().putBoolean("speak", speakReplies).apply()
        voiceButton.setImageResource(if (speakReplies) R.drawable.ic_volume_on else R.drawable.ic_volume_off)
        voiceButton.contentDescription = if (speakReplies) "Desligar a voz do Erox" else "Ligar a voz do Erox"
        if (!speakReplies) {
            tts?.stop()
            addNotice("Voz desligada. Eu respondo só por escrito.")
        } else if (!ttsReady) {
            addNotice("Não achei uma voz em português neste celular. Instale uma nas configurações de texto para fala.")
        } else {
            addNotice("Voz ligada.")
            speak("Voz ligada.")
        }
    }

    // ------------------------------------------------------------------ voz: ouvir

    private fun toggleListening() {
        if (listening) {
            stopListening(cancel = false)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        startListening()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_MIC) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            addNotice("Sem permissão do microfone eu não consigo ouvir. Você pode liberar em Configurações > Apps > Erox > Permissões. Enquanto isso, é só digitar.")
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!partial.isNullOrBlank()) {
                input.setText(partial)
                input.setSelection(input.text.length)
            }
        }

        override fun onResults(results: Bundle?) {
            setListening(false)
            val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            input.setText("")
            if (heard.isNullOrBlank()) {
                addNotice("Não ouvi nada. Toque no microfone e fale de novo.")
            } else {
                submit(heard)
            }
        }

        override fun onError(error: Int) {
            setListening(false)
            input.setText("")
            when (error) {
                SpeechRecognizer.ERROR_CLIENT -> Unit // aconteceu porque eu mesmo parei de ouvir
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    addNotice("Não ouvi nada. Toque no microfone e fale de novo.")
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    addNotice("O Erox precisa da permissão do microfone para ouvir.")
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER,
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
                    addNotice("Sem o pacote de voz em português para uso offline e sem internet. Baixe o idioma Português nas configurações de voz do Google, ou digite.")
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.cancel()
                    addNotice("O reconhecimento de voz estava ocupado. Tente de novo.")
                }
                else -> addNotice("Não consegui ouvir agora (código $error). Você pode digitar.")
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addNotice("Este celular não tem reconhecimento de voz instalado. Você pode digitar normalmente.")
            return
        }
        tts?.stop()
        val engine = try {
            recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
                recognizer = it
            }
        } catch (e: Exception) {
            addNotice("Não consegui iniciar o reconhecimento de voz neste celular.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        setListening(true)
        try {
            engine.startListening(intent)
        } catch (e: Exception) {
            setListening(false)
            addNotice("Não consegui começar a ouvir. Tente de novo.")
        }
    }

    private fun stopListening(cancel: Boolean) {
        if (!listening) return
        setListening(false)
        try {
            if (cancel) recognizer?.cancel() else recognizer?.stopListening()
        } catch (e: Exception) {
            // nada a fazer: o reconhecedor já tinha parado
        }
    }

    private fun setListening(on: Boolean) {
        listening = on
        micButton.background = circle(if (on) Palette.ACCENT else Palette.SURFACE_HI)
        micButton.imageTintList = ColorStateList.valueOf(if (on) Palette.ON_ACCENT else Palette.TEXT)
        micButton.contentDescription = if (on) "Parar de ouvir" else "Falar com o Erox"
        statusView.text = if (on) "ouvindo…" else "assistente local"
        statusView.setTextColor(if (on) Palette.ACCENT else Palette.MUTED)
    }

    // ------------------------------------------------------------------ timer

    private fun startTimer(seconds: Int) {
        cancelTimer()
        val runnable = Runnable {
            timerRunnable = null
            onTimerDone()
        }
        timerRunnable = runnable
        main.postDelayed(runnable, seconds * 1000L)
    }

    private fun cancelTimer() {
        timerRunnable?.let { main.removeCallbacks(it) }
        timerRunnable = null
    }

    @Suppress("DEPRECATION")
    private fun onTimerDone() {
        addBubble("O tempo acabou!", fromUser = false)
        try {
            getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
            RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))?.play()
        } catch (e: Exception) {
            // sem vibração ou som: a mensagem na tela já avisa
        }
        speak("O tempo acabou!", force = true)
    }

    private companion object {
        const val REQUEST_MIC = 1
        /** Depois de ficar tanto tempo fora do app, o Erox pede a digital de novo. */
        const val LOCK_AFTER_MS = 30_000L
    }
}
