package com.erox.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

internal object Palette {
    val BG: Int = Color.parseColor("#0E1319")
    val SURFACE: Int = Color.parseColor("#171E28")
    val SURFACE_HI: Int = Color.parseColor("#212B38")
    val TEXT: Int = Color.parseColor("#E8EDF3")
    val MUTED: Int = Color.parseColor("#8A97A8")
    val ACCENT: Int = Color.parseColor("#4FD1B8")
    val ON_ACCENT: Int = Color.parseColor("#06231E")
    val ERROR: Int = Color.parseColor("#FF8A80")
}

/**
 * Símbolo do Erox: anéis abertos, como as linhas de uma digital.
 * Uma onda de brilho percorre os anéis de dentro para fora.
 * O mesmo desenho é usado no ícone do app (ic_launcher_foreground.xml).
 */
internal class FingerprintOrb(context: Context) : View(context) {

    private class Ring(val radius: Float, val start: Float, val sweep: Float)

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bounds = RectF()
    private var pulse = 0f

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
    }

    var tint: Int = Palette.ACCENT
        set(value) {
            field = value
            invalidate()
        }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnimation()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        updateAnimation()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        updateAnimation()
    }

    private fun updateAnimation() {
        val shouldRun = isAttachedToWindow && isShown && windowVisibility == VISIBLE && ValueAnimator.areAnimatorsEnabled()
        if (shouldRun) {
            if (!animator.isStarted) animator.start()
        } else {
            animator.cancel()
            pulse = 0.5f
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val maxRadius = min(width, height) / 2f * 0.94f
        ring.strokeWidth = maxRadius * 0.05f
        ring.color = tint

        for ((i, r) in RINGS.withIndex()) {
            val t = i / (RINGS.size - 1).toFloat()
            var d = abs(pulse - t)
            d = min(d, 1f - d)
            val wave = max(0f, 1f - d * 3.2f)
            ring.alpha = (80 + 175 * wave).toInt()
            val radius = r.radius * maxRadius
            bounds.set(cx - radius, cy - radius, cx + radius, cy + radius)
            canvas.drawArc(bounds, r.start, r.sweep, false, ring)
        }
    }

    private companion object {
        val RINGS = listOf(
            Ring(0.12f, -70f, 320f),
            Ring(0.26f, 20f, 290f),
            Ring(0.40f, -150f, 300f),
            Ring(0.54f, 60f, 280f),
            Ring(0.68f, -30f, 300f),
            Ring(0.82f, 120f, 270f),
        )
    }
}
