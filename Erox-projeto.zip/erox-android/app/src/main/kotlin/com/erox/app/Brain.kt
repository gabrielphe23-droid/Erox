package com.erox.app

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.Normalizer
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

/** Onde o cérebro guarda o que aprende (nome, anotações, respostas ensinadas). */
interface Store {
    fun get(key: String): String?
    fun put(key: String, value: String)
    fun remove(key: String)
}

/** Coisas que o cérebro pede para o app fazer além de responder com texto. */
sealed class Action {
    object None : Action()
    data class Timer(val seconds: Int) : Action()
    object CancelTimer : Action()
    object Lock : Action()
    object ClearChat : Action()
    object StopSpeaking : Action()
}

data class Reply(val text: String, val action: Action = Action.None)

/**
 * O "cérebro" do Erox: um assistente simples, baseado em regras, que roda 100% dentro do
 * aparelho. Não usa internet e não tem nenhuma dependência do Android, então dá para testar
 * em qualquer computador.
 */
class Brain(
    private val store: Store,
    private val now: () -> LocalDateTime = { LocalDateTime.now() },
    private val random: Random = Random.Default,
) {
    private enum class Pending { NOTE, CLEAR_NOTES, FORGET_TAUGHT, RESET_ALL }

    private var pending: Pending? = null

    fun respond(input: String): Reply {
        val text = input.trim()
        if (text.isEmpty()) return Reply("Pode falar ou digitar, estou aqui.")
        val spoken = words(text)
        val w = stripCallName(spoken)

        // 1. Conversas em andamento (confirmações e anotação em duas etapas)
        val p = pending
        if (p != null) {
            pending = null
            return continuePending(p, text, w)
        }

        // 2. Ensinar o Erox: "quando eu disser X, responda Y"
        teachRegex.matchEntire(text)?.let { m ->
            val trigger = words(m.groupValues[1])
            val answer = clean(m.groupValues[2], 300)
            if (trigger.isEmpty() || answer.isEmpty()) return Reply("Não entendi o que ensinar. Diga: quando eu disser oi, responda e aí chefe.")
            if (trigger.length > 80) return Reply("Essa frase ficou grande demais. Escolha algo mais curto.")
            val list = loadTaught().filter { it.first != trigger }.toMutableList()
            if (list.size >= 100) return Reply("Já aprendi o máximo de respostas. Peça para eu esquecer algumas.")
            list.add(trigger to answer)
            saveTaught(list)
            return Reply("Aprendi! Quando você disser \"${m.groupValues[1].trim()}\", eu respondo \"$answer\".")
        }

        // 3. Respostas que o usuário ensinou valem mais que as padrão
        loadTaught().firstOrNull { it.first == w || it.first == spoken }?.let { return Reply(it.second) }

        // 4. Comandos que mexem no app
        if (w in setOf("bloquear", "bloqueia", "trancar", "tranca", "travar", "bloquear app", "bloquear o app", "bloqueia o app", "tranca o app")) {
            return Reply("Bloqueando.", Action.Lock)
        }
        if (w in setOf("limpar conversa", "limpar a conversa", "limpa a conversa", "limpar tela", "limpa a tela", "limpar chat", "limpa o chat", "apagar conversa", "apaga a conversa")) {
            return Reply("Conversa limpa.", Action.ClearChat)
        }
        if (w in setOf("silencio", "para", "pare", "parar", "chega", "cala a boca", "fica quieto", "para de falar", "pare de falar")) {
            return Reply("Ok.", Action.StopSpeaking)
        }

        // 5. Ensinamentos e reinício
        if (has(w, "o que voce aprendeu") || has(w, "o que eu te ensinei") || has(w, "o que eu ensinei") || has(w, "minhas respostas")) {
            val t = loadTaught()
            if (t.isEmpty()) return Reply("Ainda não me ensinou nada. Diga: quando eu disser oi, responda e aí chefe.")
            return Reply("Isso eu aprendi com você:\n" + t.joinToString("\n") { "• ${it.first} → ${it.second}" })
        }
        if (has(w, "esquece o que te ensinei") || has(w, "esquecer o que te ensinei") || has(w, "esquece o que eu te ensinei") ||
            has(w, "apaga o que voce aprendeu") || has(w, "apagar o que voce aprendeu") || has(w, "esquecer tudo que eu ensinei")
        ) {
            if (loadTaught().isEmpty()) return Reply("Não tenho nada ensinado para esquecer.")
            pending = Pending.FORGET_TAUGHT
            return Reply("Quer mesmo que eu esqueça tudo que você me ensinou? Responda sim para confirmar.")
        }
        if (w in setOf("resetar", "resetar erox", "apagar tudo", "limpar tudo", "esquecer tudo", "esquece tudo", "apaga tudo")) {
            pending = Pending.RESET_ALL
            return Reply("Isso apaga seu nome, suas anotações e tudo que me ensinou. Responda sim para confirmar.")
        }

        // 6. Timer
        tryTimer(w)?.let { return it }

        // 7. Anotações
        tryNotes(text, w)?.let { return it }

        // 8. Nome do usuário
        tryName(text, w)?.let { return it }

        // 9. Ajuda e identidade
        if (w in setOf("ajuda", "me ajuda", "ajudar", "comandos", "menu", "help", "o que voce faz", "o que voce sabe fazer", "o que voce sabe", "o que voce pode fazer", "o que da pra fazer")) {
            return Reply(HELP)
        }
        if (w in setOf("quem e voce", "quem voce e", "qual seu nome", "qual o seu nome", "como voce se chama", "como se chama", "o que voce e", "voce e quem", "se apresenta", "se apresente")) {
            return Reply("Eu sou o Erox, um assistente simples que mora aqui dentro do seu celular. Meu cérebro funciona sem internet.")
        }
        if (has(w, "quem te criou") || has(w, "quem te fez") || has(w, "quem fez voce") || has(w, "quem criou voce")) {
            return Reply("Fui feito sob medida para você, como um projeto do zero.")
        }

        // 10. Hora e data
        tryTimeDate(w)?.let { return it }

        // 11. Contas
        tryMath(text)?.let { return it }

        // 12. Brincadeiras
        tryFun(w)?.let { return it }

        // 13. Conversa rápida
        trySmallTalk(w)?.let { return it }

        return fallback(text, w)
    }

    // ---------------------------------------------------------------- conversas em andamento

    private fun continuePending(p: Pending, text: String, w: String): Reply {
        return when (p) {
            Pending.NOTE ->
                if (w in CANCEL) Reply("Tudo bem, não anotei nada.") else addNote(text)
            Pending.CLEAR_NOTES ->
                if (w in YES) { store.remove(KEY_NOTES); Reply("Pronto, apaguei todas as anotações.") } else Reply("Cancelado. Suas anotações continuam aqui.")
            Pending.FORGET_TAUGHT ->
                if (w in YES) { store.remove(KEY_TAUGHT); Reply("Pronto, esqueci tudo que você tinha me ensinado.") } else Reply("Cancelado. Continuo lembrando.")
            Pending.RESET_ALL ->
                if (w in YES) {
                    store.remove(KEY_NOTES); store.remove(KEY_TAUGHT); store.remove(KEY_NAME)
                    Reply("Pronto, voltei ao começo. Não sei mais seu nome nem nada do que guardei.")
                } else Reply("Cancelado. Nada foi apagado.")
        }
    }

    // ---------------------------------------------------------------- anotações

    private fun tryNotes(text: String, w: String): Reply? {
        // "me lembra de X" → vira anotação (o Erox ainda não avisa na hora certa)
        remindRegex.matchEntire(text)?.let { m ->
            val note = clean(m.groupValues[1], 300)
            if (note.isNotEmpty()) {
                saveNote(note)?.let { return Reply(it) }
                return Reply("Anotei: $note. Ainda não consigo te avisar na hora certa, mas isso fica nas suas anotações.")
            }
        }

        // listar
        if (has(w, "minhas notas") || has(w, "minhas anotacoes") || has(w, "o que eu anotei") || has(w, "ver notas") ||
            has(w, "ver anotacoes") || has(w, "mostra as notas") || has(w, "mostra as anotacoes") || has(w, "mostrar notas") ||
            has(w, "mostrar anotacoes") || has(w, "lista de notas") || w == "notas" || w == "anotacoes" || has(w, "ler minhas notas") ||
            has(w, "le minhas notas") || has(w, "le as notas") || has(w, "ler as notas")
        ) {
            val notes = loadNotes()
            if (notes.isEmpty()) return Reply("Você ainda não tem anotações. Diga \"anota\" e o que quiser guardar.")
            return Reply("Suas anotações:\n" + notes.mapIndexed { i, n -> "${i + 1}. $n" }.joinToString("\n"))
        }

        // apagar uma ou todas
        if (Regex("^(apaga|apagar|apague|remove|remover|exclui|excluir|deleta|deletar|limpa|limpar)( todas)?( as| a| minhas)?( minhas)? (nota|notas|anotacao|anotacoes)$").matches(w) &&
            (w.contains("todas") || w.endsWith("notas") || w.endsWith("anotacoes"))
        ) {
            if (loadNotes().isEmpty()) return Reply("Você não tem anotações para apagar.")
            pending = Pending.CLEAR_NOTES
            return Reply("Quer apagar todas as suas anotações? Responda sim para confirmar.")
        }
        Regex("^(?:apaga|apagar|apague|remove|remover|exclui|excluir|deleta|deletar|risca|riscar)(?: a| as)? (?:nota|anotacao)(?: numero| n)? (\\d+)$").matchEntire(w)?.let { m ->
            val idx = m.groupValues[1].toInt()
            val notes = loadNotes().toMutableList()
            if (idx < 1 || idx > notes.size) return Reply("Não achei a anotação $idx. Você tem ${notes.size}.")
            val removed = notes.removeAt(idx - 1)
            saveNotes(notes)
            return Reply("Apaguei a anotação $idx: $removed.")
        }

        // anotar (primeiro o pedido sem conteúdo, depois o pedido completo)
        if (w in setOf("anota", "anote", "anotar", "anota ai", "anota isso", "anota uma nota", "guarda", "guarda isso", "salva", "salva isso")) {
            pending = Pending.NOTE
            return Reply("O que eu anoto?")
        }
        noteRegex.matchEntire(text)?.let { m ->
            val note = clean(m.groupValues[1], 300)
            if (note.isNotEmpty()) return saveNote(note)?.let { Reply(it) } ?: Reply("Anotado: $note.")
        }
        return null
    }

    private fun addNote(text: String): Reply {
        val note = clean(text, 300)
        return saveNote(note)?.let { Reply(it) } ?: Reply("Anotado: $note.")
    }

    /** Devolve uma mensagem de erro se não deu para guardar, ou null se guardou. */
    private fun saveNote(note: String): String? {
        val notes = loadNotes().toMutableList()
        if (notes.size >= 200) return "Você já tem anotações demais (200). Apague algumas para eu guardar mais."
        notes.add(note)
        saveNotes(notes)
        return null
    }

    private fun loadNotes(): List<String> =
        (store.get(KEY_NOTES) ?: "").split('\n').filter { it.isNotBlank() }

    private fun saveNotes(notes: List<String>) {
        if (notes.isEmpty()) store.remove(KEY_NOTES) else store.put(KEY_NOTES, notes.joinToString("\n"))
    }

    // ---------------------------------------------------------------- respostas ensinadas

    private fun loadTaught(): List<Pair<String, String>> =
        (store.get(KEY_TAUGHT) ?: "").split('\n').mapNotNull { line ->
            val i = line.indexOf('\t')
            if (i <= 0) null else line.substring(0, i) to line.substring(i + 1)
        }

    private fun saveTaught(list: List<Pair<String, String>>) {
        if (list.isEmpty()) store.remove(KEY_TAUGHT) else store.put(KEY_TAUGHT, list.joinToString("\n") { "${it.first}\t${it.second}" })
    }

    // ---------------------------------------------------------------- nome

    private fun tryName(text: String, w: String): Reply? {
        nameRegex.find(text)?.let { m ->
            val name = cleanName(m.groupValues[1])
            if (name.isNotEmpty()) {
                store.put(KEY_NAME, name)
                return Reply("Prazer, $name! Vou lembrar de você.")
            }
        }
        if (has(w, "qual meu nome") || has(w, "qual e o meu nome") || has(w, "como eu me chamo") || has(w, "voce sabe meu nome") ||
            has(w, "sabe meu nome") || has(w, "voce sabe quem eu sou") || w == "quem sou eu"
        ) {
            val n = store.get(KEY_NAME)
            return if (n.isNullOrBlank()) Reply("Ainda não sei. Diga: meu nome é, e o seu nome.") else Reply("Você é $n.")
        }
        if (has(w, "esquece meu nome") || has(w, "esquecer meu nome") || has(w, "apaga meu nome")) {
            store.remove(KEY_NAME)
            return Reply("Pronto, esqueci seu nome.")
        }
        return null
    }

    private fun cleanName(raw: String): String {
        val stop = setOf("e", "mas", "que", "porque", "pq", "quero", "queria", "agora", "ok")
        val parts = ArrayList<String>()
        for (word in raw.trim().trimEnd('.', '!', '?', ',', ';', ':').split(Regex("\\s+"))) {
            val bare = word.trim('.', '!', '?', ',', ';', ':')
            if (bare.isEmpty()) continue
            if (parts.isNotEmpty() && fold(bare) in stop) break
            if (!bare.all { it.isLetter() || it == '-' || it == '\'' }) break
            parts.add(bare)
            if (parts.size == 3) break
        }
        val small = setOf("da", "de", "do", "das", "dos", "e")
        return parts.joinToString(" ") { part ->
            if (part.lowercase() in small) part.lowercase() else part.lowercase().replaceFirstChar { it.uppercase() }
        }.take(30)
    }

    // ---------------------------------------------------------------- timer

    private fun tryTimer(w: String): Reply? {
        val hasTimerWord = has(w, "timer") || has(w, "temporizador") || has(w, "cronometro") ||
            has(w, "me avisa em") || has(w, "me avise em") || has(w, "contagem regressiva")
        if (!hasTimerWord) return null
        val tokens = wordsToNumbers(w.split(' '))

        var total = 0L
        var found = false
        var i = 0
        while (i < tokens.size) {
            val n = tokens[i].toIntOrNull()
            val unit = tokens.getOrNull(i + 1)
            if (n != null && unit != null) {
                val mult = when (unit) {
                    "segundo", "segundos" -> 1
                    "minuto", "minutos" -> 60
                    "hora", "horas" -> 3600
                    else -> 0
                }
                if (mult > 0) {
                    total += n.toLong() * mult
                    found = true
                    i += 2
                    continue
                }
            }
            if (tokens[i] == "meia" && unit == "hora") {
                total += 1800
                found = true
                i += 2
                continue
            }
            i++
        }

        val cancelWord = tokens.any { it in setOf("cancela", "cancelar", "cancele") }
        val stopWord = tokens.any { it in setOf("para", "parar", "pare", "desliga", "desligar", "apaga", "apagar") }
        if (cancelWord || (stopWord && !found)) return Reply("Timer cancelado.", Action.CancelTimer)
        if (!found || total <= 0) return Reply("Por quanto tempo? Diga, por exemplo: timer de 5 minutos.")
        if (total > 86_400) return Reply("Eu só consigo marcar timers de até 24 horas.")
        return Reply("Timer de ${describeDuration(total.toInt())} ligado. Eu aviso quando acabar, se o app estiver aberto.", Action.Timer(total.toInt()))
    }

    private fun describeDuration(total: Int): String {
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add(if (h == 1) "1 hora" else "$h horas")
        if (m > 0) parts.add(if (m == 1) "1 minuto" else "$m minutos")
        if (s > 0) parts.add(if (s == 1) "1 segundo" else "$s segundos")
        return parts.joinToString(" e ")
    }

    // ---------------------------------------------------------------- hora e data

    private fun tryTimeDate(w: String): Reply? {
        val asksTime = has(w, "que horas sao") || has(w, "que horas e") || has(w, "que hora e") || has(w, "me diz as horas") ||
            has(w, "me diga as horas") || has(w, "hora atual") || has(w, "qual a hora") || has(w, "qual e a hora") ||
            w == "horas" || w == "hora" || has(w, "me fala as horas")
        if (asksTime) {
            val t = now()
            val text = when {
                t.hour == 12 && t.minute == 0 -> "É meio-dia."
                t.hour == 0 && t.minute == 0 -> "É meia-noite."
                t.hour <= 1 -> "É %02d:%02d.".format(Locale.ROOT, t.hour, t.minute)
                else -> "São %02d:%02d.".format(Locale.ROOT, t.hour, t.minute)
            }
            return Reply(text)
        }
        val asksDate = has(w, "que dia e hoje") || has(w, "que dia e amanha") || has(w, "que dia foi ontem") || has(w, "que dia e ontem") ||
            has(w, "data de hoje") || has(w, "qual a data") || has(w, "qual e a data") || has(w, "que dia da semana") ||
            has(w, "dia da semana") || has(w, "que data e hoje") || w == "data" || has(w, "que dia e") || has(w, "em que dia estamos")
        if (asksDate) {
            val fmt = DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM 'de' yyyy", PT_BR)
            val today = now().toLocalDate()
            return when {
                has(w, "amanha") -> Reply("Amanhã será ${today.plusDays(1).format(fmt)}.")
                has(w, "ontem") -> Reply("Ontem foi ${today.minusDays(1).format(fmt)}.")
                else -> Reply("Hoje é ${today.format(fmt)}.")
            }
        }
        return null
    }

    // ---------------------------------------------------------------- brincadeiras

    private fun tryFun(w: String): Reply? {
        if (has(w, "piada") || has(w, "me faz rir") || has(w, "me faca rir") || has(w, "me alegra")) {
            return Reply(JOKES[random.nextInt(JOKES.size)])
        }
        if (has(w, "cara ou coroa")) {
            return Reply(if (random.nextBoolean()) "Deu cara!" else "Deu coroa!")
        }
        if (w in setOf("dado", "joga um dado", "jogar um dado", "rola um dado", "rolar um dado", "lanca um dado", "role um dado", "joga o dado")) {
            return Reply("Caiu ${random.nextInt(1, 7)}.")
        }
        if (has(w, "sorteia") || has(w, "sorteie") || has(w, "sortear") || has(w, "numero aleatorio") || has(w, "numero de sorte")) {
            val nums = Regex("\\d+").findAll(w).mapNotNull { it.value.toIntOrNull() }.toList()
            var lo = 1
            var hi = 100
            if (nums.size >= 2) {
                lo = minOf(nums[0], nums[1])
                hi = maxOf(nums[0], nums[1])
            } else if (nums.size == 1) {
                hi = nums[0]
                if (hi < 1) lo = hi
            }
            if (hi == Int.MAX_VALUE) hi -= 1
            return Reply("Sorteei o número ${random.nextInt(lo, hi + 1)}.")
        }
        return null
    }

    // ---------------------------------------------------------------- conversa rápida

    private fun trySmallTalk(w: String): Reply? {
        if (w == "erox") return Reply("Estou aqui! Em que posso ajudar?")
        if (has(w, "tudo bem") || has(w, "como vai") || has(w, "como voce esta") || has(w, "como vc esta") ||
            has(w, "como esta voce") || has(w, "td bem") || has(w, "como voce ta") || has(w, "como vai voce") || has(w, "como ce ta")
        ) {
            return Reply("Tudo certo por aqui! E com você?")
        }
        if (w in GREETINGS || GREETINGS.any { w.startsWith("$it ") }) {
            val h = now().hour
            val period = when {
                w.startsWith("bom dia") -> "Bom dia"
                w.startsWith("boa tarde") -> "Boa tarde"
                w.startsWith("boa noite") -> "Boa noite"
                h in 5..11 -> "Bom dia"
                h in 12..17 -> "Boa tarde"
                else -> "Boa noite"
            }
            val name = store.get(KEY_NAME)
            return Reply(if (name.isNullOrBlank()) "$period! Em que posso ajudar?" else "$period, $name! Em que posso ajudar?")
        }
        if (w in setOf("obrigado", "obrigada", "valeu", "vlw", "brigado", "brigada", "muito obrigado", "muito obrigada", "obrigadao")) return Reply("De nada!")
        if (w in setOf("tchau", "ate logo", "ate mais", "flw", "falou", "ate amanha", "ate depois", "xau")) return Reply("Até mais!")
        if (has(w, "te amo") || has(w, "gosto de voce")) return Reply("Fico feliz em ajudar. Sou só um app, mas estou aqui sempre que precisar.")
        if (w in setOf("sim", "nao", "ok", "certo", "beleza", "legal", "entendi", "show", "blz")) return Reply("Certo. Se precisar de algo, é só dizer.")
        return null
    }

    private fun fallback(text: String, w: String): Reply {
        val askedQuestion = text.trimEnd().endsWith("?") ||
            QUESTION_STARTS.any { w == it || w.startsWith("$it ") }
        if (askedQuestion) {
            return Reply("Não sei responder isso. Eu funciono sem internet e só conheço o que está na lista do \"ajuda\". Você também pode me ensinar uma resposta.")
        }
        val options = listOf(
            "Ainda não sei fazer isso. Diga \"ajuda\" para ver o que eu sei.",
            "Não entendi. Tente \"ajuda\" para ver os comandos.",
            "Essa eu não peguei. Diga \"ajuda\" e eu mostro o que sei fazer.",
        )
        return Reply(options[random.nextInt(options.size)])
    }

    // ---------------------------------------------------------------- contas

    private fun tryMath(input: String): Reply? {
        var t = fold(input).replace('×', '*').replace('÷', '/').replace('−', '-').replace(Regex("[?!]"), " ")
        val hadCue = MATH_CUE.containsMatchIn(t)
        t = MATH_CUE.replace(t, " ")

        t = Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:%|por cento)\\s*d[eo]\\s*").replace(t) { " ( ${it.groupValues[1]} / 100 ) * " }
        t = t.replace("raiz quadrada de", " sqrt ").replace("raiz de", " sqrt ")
        t = t.replace("elevado ao quadrado", " ^ 2 ").replace("elevado ao cubo", " ^ 3 ")
        t = t.replace(Regex("\\bao quadrado\\b"), " ^ 2 ").replace(Regex("\\bao cubo\\b"), " ^ 3 ")
        t = t.replace(Regex("\\belevado ao?\\b"), " ^ ")
        t = t.replace(Regex("\\bmultiplicado por\\b|\\bvezes\\b"), " * ")
        t = t.replace(Regex("\\bdividido por\\b|\\bdividido\\b"), " / ")
        t = t.replace(Regex("\\bmais\\b"), " + ").replace(Regex("\\bmenos\\b"), " - ")
        t = t.replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), " * ")
        t = t.replace(Regex("([+*/^()-])"), " $1 ")

        var tokens = t.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return null
        tokens = wordsToNumbers(tokens)

        val valid = Regex("^\\d+(?:[.,]\\d+)*$")
        val ops = setOf("+", "-", "*", "/", "^", "(", ")", "sqrt")
        val kept = ArrayList<String>()
        for (tok in tokens) {
            when {
                valid.matches(tok) || tok in ops -> kept.add(tok)
                hadCue -> Unit // com "quanto é", "calcula"… ignora palavras soltas como "reais"
                else -> return null
            }
        }
        if (kept.none { valid.matches(it) }) return null
        if (kept.none { it in setOf("+", "-", "*", "/", "^", "sqrt") }) return null

        return try {
            val value = ExprParser(kept).parse()
            if (value.isNaN() || value.isInfinite()) Reply("Esse resultado é grande demais para eu mostrar.")
            else Reply("O resultado é ${formatNumber(value)}.")
        } catch (e: MathError) {
            val msg = e.message
            if (msg.isNullOrBlank()) null else Reply(msg)
        }
    }

    private class MathError(message: String) : Exception(message)

    private class ExprParser(private val t: List<String>) {
        private var i = 0

        fun parse(): Double {
            val v = expr()
            if (i != t.size) throw MathError("")
            return v
        }

        private fun peek(): String? = t.getOrNull(i)

        private fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    "+" -> { i++; v += term() }
                    "-" -> { i++; v -= term() }
                    else -> return v
                }
            }
        }

        private fun term(): Double {
            var v = unary()
            while (true) {
                when (peek()) {
                    "*" -> { i++; v *= unary() }
                    "/" -> {
                        i++
                        val d = unary()
                        if (d == 0.0) throw MathError("Não dá para dividir por zero.")
                        v /= d
                    }
                    else -> return v
                }
            }
        }

        private fun unary(): Double = when (peek()) {
            "-" -> { i++; -unary() }
            "+" -> { i++; unary() }
            else -> power()
        }

        private fun power(): Double {
            val base = atom()
            if (peek() == "^") {
                i++
                return base.pow(unary())
            }
            return base
        }

        private fun atom(): Double {
            val tok = peek() ?: throw MathError("")
            i++
            return when (tok) {
                "sqrt" -> {
                    val v = unary()
                    if (v < 0) throw MathError("Não existe raiz quadrada real de número negativo.")
                    sqrt(v)
                }
                "(" -> {
                    val v = expr()
                    if (peek() != ")") throw MathError("")
                    i++
                    v
                }
                else -> parseNumber(tok) ?: throw MathError("")
            }
        }
    }

    // ---------------------------------------------------------------- utilidades

    private companion object {
        const val KEY_NAME = "name"
        const val KEY_NOTES = "notes"
        const val KEY_TAUGHT = "taught"

        val PT_BR: Locale = Locale.forLanguageTag("pt-BR")

        val YES = setOf("sim", "s", "confirmo", "confirmar", "pode", "pode apagar", "claro", "isso", "com certeza", "ok", "pode sim")
        val CANCEL = setOf("nada", "cancela", "cancelar", "deixa", "deixa pra la", "esquece", "nao", "nao quero")

        val GREETINGS = setOf(
            "oi", "ola", "opa", "eai", "e ai", "salve", "fala", "hey", "hello", "bom dia", "boa tarde", "boa noite", "oie", "oii",
        )

        val QUESTION_STARTS = listOf("o que", "quem", "qual", "quais", "como", "quando", "onde", "por que", "porque", "quanto", "quantos", "quantas", "pra que", "para que")

        val MATH_CUE = Regex("\\b(?:quanto (?:e|eh|da|fica|vale|seria|sera)|calcul\\w*|resultado(?: d[aeo])?|resolv\\w*|conta d[aeo]|me diz quanto e|diz quanto e)\\b")

        val teachRegex = Regex(
            "^quando eu (?:disser|falar|digitar|escrever|mandar)\\s+[\"“']?(.+?)[\"”']?\\s*[,;:]?\\s+(?:voc[eê]\\s+)?(?:responda|responde|diga|diz|fale|fala|retorne)(?:\\s+que)?\\s+[\"“']?(.+?)[\"”']?\\s*[.!]?$",
            RegexOption.IGNORE_CASE,
        )

        val noteRegex = Regex(
            "^(?:anota|anote|anotar|guarda|guarde|guardar|salva|salve|salvar)(?:\\s+(?:isso|ai|aí|aqui|uma nota|a nota|nota|que|pra mim|para mim))?\\s*[:,\\-]?\\s+(.+)$",
            RegexOption.IGNORE_CASE,
        )

        val remindRegex = Regex(
            "^(?:me lembra|me lembre|lembra|lembre|me avisa|me avise)(?:-me)?\\s+(?:de|que|para|pra)\\s+(.+)$",
            RegexOption.IGNORE_CASE,
        )

        val nameRegex = Regex(
            "(?:^|\\s)(?:meu nome (?:[eé]|seria)|me chamo|pode me chamar de|pode me chamar|me chama de|me chame de|meu apelido [eé])\\s+(.+)$",
            RegexOption.IGNORE_CASE,
        )

        val UNITS = mapOf(
            "zero" to 0, "um" to 1, "uma" to 1, "dois" to 2, "duas" to 2, "tres" to 3, "quatro" to 4, "cinco" to 5, "seis" to 6,
            "sete" to 7, "oito" to 8, "nove" to 9, "dez" to 10, "onze" to 11, "doze" to 12, "treze" to 13, "catorze" to 14,
            "quatorze" to 14, "quinze" to 15, "dezesseis" to 16, "dezessete" to 17, "dezoito" to 18, "dezenove" to 19,
        )
        val TENS = mapOf(
            "vinte" to 20, "trinta" to 30, "quarenta" to 40, "cinquenta" to 50, "sessenta" to 60,
            "setenta" to 70, "oitenta" to 80, "noventa" to 90,
        )

        const val HELP = "Eu sou simples, mas faço isto:\n" +
            "• Hora e data: \"que horas são?\", \"que dia é hoje?\"\n" +
            "• Contas: \"quanto é 15 vezes 3?\", \"20% de 150\", \"raiz de 81\"\n" +
            "• Anotações: \"anota comprar pão\", \"minhas anotações\", \"apaga anotação 2\"\n" +
            "• Timer: \"timer de 5 minutos\"\n" +
            "• Seu nome: \"meu nome é Gabriel\"\n" +
            "• Brincadeiras: \"conta uma piada\", \"cara ou coroa\", \"joga um dado\"\n" +
            "• Me ensinar: \"quando eu disser oi, responda e aí chefe\"\n" +
            "• \"bloquear\" tranca o app, \"silêncio\" para minha voz."

        val JOKES = listOf(
            "Por que o livro de matemática ficou triste? Porque tinha muitos problemas.",
            "O que o zero disse para o oito? Belo cinto!",
            "Por que o computador foi ao médico? Porque estava com vírus.",
            "Qual é o animal mais antigo? A zebra, porque é em preto e branco.",
            "O que a vaca foi fazer no espaço? Procurar o vácuo!",
            "Por que o esqueleto não quis brigar? Porque não tinha estômago para isso.",
            "Qual é o fim da picada? Quando o mosquito vai embora.",
            "Por que o celular foi pra escola? Para ficar mais inteligente.",
        )

        private val accents = Regex("\\p{InCombiningDiacriticalMarks}+")

        /** minúsculas e sem acentos; o resto fica como está. */
        fun fold(s: String): String =
            accents.replace(Normalizer.normalize(s.lowercase(PT_BR), Normalizer.Form.NFD), "")

        /** só letras e números, separados por um espaço. */
        fun words(s: String): String =
            fold(s).replace(Regex("[^a-z0-9]+"), " ").trim()

        /** tira "erox" quando a pessoa chama o assistente pelo nome ("Erox, que horas são?"). */
        fun stripCallName(w: String): String {
            var r = w
            for (prefix in listOf("ei erox ", "ok erox ", "e ai erox ", "oi erox ", "ola erox ", "hey erox ", "fala erox ", "erox ")) {
                if (r.startsWith(prefix)) { r = r.removePrefix(prefix); break }
            }
            if (r.endsWith(" erox")) r = r.removeSuffix(" erox")
            return if (r.isEmpty()) w else r
        }

        /** a frase contém essas palavras, inteiras? */
        fun has(w: String, phrase: String): Boolean = " $w ".contains(" $phrase ")

        fun clean(s: String, max: Int): String =
            s.replace('\t', ' ').replace(Regex("\\s+"), " ").trim().trimEnd('.', '!').trim().take(max)

        fun isNumWord(t: String) = t in UNITS || t in TENS || t == "cem" || t == "cento" || t == "mil"

        /** "vinte e cinco" → "25", "dois mil" → "2000". Outras palavras ficam como estão. */
        fun wordsToNumbers(tokens: List<String>): List<String> {
            val out = ArrayList<String>()
            var i = 0
            while (i < tokens.size) {
                if (!isNumWord(tokens[i])) {
                    out.add(tokens[i]); i++; continue
                }
                var total = 0
                var current = 0
                var j = i
                while (j < tokens.size) {
                    val t = tokens[j]
                    when {
                        t in UNITS -> { current += UNITS.getValue(t); j++ }
                        t in TENS -> { current += TENS.getValue(t); j++ }
                        t == "cem" || t == "cento" -> { current += 100; j++ }
                        t == "mil" -> { total += (if (current == 0) 1 else current) * 1000; current = 0; j++ }
                        t == "e" && j > i && j + 1 < tokens.size && isNumWord(tokens[j + 1]) -> j++
                        else -> break
                    }
                }
                out.add((total + current).toString())
                i = j
            }
            return out
        }

        /** Entende "1.000,50", "3,5", "2.5" e "1.000". */
        fun parseNumber(s: String): Double? {
            val n = when {
                s.contains(',') && s.contains('.') -> s.replace(".", "").replace(',', '.')
                s.contains(',') -> if (s.count { it == ',' } > 1) return null else s.replace(',', '.')
                s.contains('.') -> if (Regex("^[1-9]\\d{0,2}(\\.\\d{3})+$").matches(s)) s.replace(".", "") else s
                else -> s
            }
            return n.toDoubleOrNull()
        }

        fun formatNumber(v: Double): String {
            if (abs(v) >= 1e15) return String.format(Locale.ROOT, "%.4e", v)
            val plain = BigDecimal(v).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
            return if (plain == "-0") "0" else plain.replace('.', ',')
        }
    }
}
