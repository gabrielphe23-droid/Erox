# Erox

Assistente simples para Android que mora dentro do celular. Abre só com a sua digital, você fala ou digita, e ele responde por escrito e em voz. O "cérebro" funciona sem internet.

## O que o Erox faz

- Hora e data: "que horas são?", "que dia é amanhã?"
- Contas: "quanto é 15 vezes 3?", "20% de 150", "raiz de 81"
- Anotações: "anota comprar pão", "minhas anotações", "apaga anotação 2"
- Timer: "timer de 5 minutos" (avisa com vibração e som se o app estiver aberto)
- Seu nome: "meu nome é Gabriel"
- Brincadeiras: "conta uma piada", "cara ou coroa", "joga um dado"
- Você ensina: "quando eu disser oi, responda e aí chefe"
- "bloquear" tranca o app, "silêncio" para a voz dele, "ajuda" mostra tudo

Ele é simples de propósito: não conversa sobre qualquer assunto, só faz o que está na lista acima.

## Como gerar o instalador (.apk)

### Caminho 1: Android Studio (no computador)

1. Instale o Android Studio: https://developer.android.com/studio
2. Abra o Android Studio, escolha **Open** e selecione esta pasta (a que tem o arquivo `settings.gradle.kts`).
3. Espere o carregamento terminar (a barra de progresso embaixo some). Na primeira vez ele baixa bastante coisa.
4. Menu **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Quando aparecer o aviso, clique em **locate**. O arquivo é o `app-debug.apk`.
6. Passe o arquivo para o celular (cabo, Drive ou WhatsApp), toque nele e permita "instalar apps desconhecidos" quando o Android pedir.

Se preferir, ligue o celular no computador por cabo, ative a **Depuração USB** e aperte o botão verde **Run**: o app já abre no celular.

### Caminho 2: GitHub (sem instalar nada)

1. Crie uma conta em github.com e um repositório novo.
2. Envie todos os arquivos desta pasta, incluindo a pasta escondida `.github`.
3. Na aba **Actions**, escolha **Gerar APK do Erox** e clique em **Run workflow**.
4. Quando terminar (uns 5 minutos), baixe o arquivo **Erox-apk** no fim da página. Dentro do zip está o `app-debug.apk`.

## No primeiro uso

- O celular precisa ter pelo menos uma **digital cadastrada** (Configurações > Segurança). Se não tiver, o Erox mostra o caminho.
- Permita o **microfone** quando ele pedir.
- Para ouvir em português sem internet, baixe o idioma Português em Configurações > Google > Reconhecimento de voz offline. Sem isso a voz pode precisar de internet; digitar sempre funciona.
- Para ele falar, o celular precisa ter uma voz de texto para fala em português.

## Limites

- Precisa de Android 10 ou mais novo.
- A digital protege a abertura do app. Ele também tranca sozinho depois de 30 segundos fora da tela.
- As anotações e o que você ensina ficam só neste celular. Desinstalar o app apaga tudo.
- "Me lembra de..." vira uma anotação, ele ainda não avisa na hora marcada.
- O timer só toca com o app aberto.
